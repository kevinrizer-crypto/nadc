# Project Brief: Neighbors Against Data Centers (NADC)
### Prepared for Freename.ai Agents — Business DNA, Website Build, Brand, Content & Visibility

---

## 1. Business Identity

**Organization name:** Neighbors Against Data Centers (NADC)

**One-line description:** The national clearinghouse for communities facing data center development — research, organizing tools, and direct action in one place.

**Mission statement:** Neighbors Against Data Centers equips residents, neighborhood groups, and local officials with credible information and practical tools to evaluate, question, and — where warranted — oppose data center construction in their communities.

**Category / vertical:** Civic advocacy nonprofit / community organizing platform / public-interest research hub.

**Positioning statement:** NADC is the foremost authority on grassroots opposition to data center construction in the United States. We are fact-based, not hysterical. We don't oppose technology — we oppose communities being left out of decisions about water, power, noise, land, and tax dollars that will affect them for decades. Where industry has lobbyists, neighbors have NADC.

**Why now (market context for positioning copy):** The AI buildout has triggered the largest wave of data center construction in history — and the largest wave of local opposition. Projects are being approved through NDAs, fast-tracked rezonings, and closed-door incentive deals before residents learn what's coming. Opposition is exploding nationwide but is fragmented: every town fights alone, relearning the same lessons. NADC consolidates that knowledge into one national resource.

**Brand archetype:** The Informed Advocate. Equal parts investigative researcher and neighbor at the fence line. Think "Consumer Reports meets a town hall."

---

## 2. Audience

**Primary personas:**

1. **The Alarmed Homeowner** — Just learned a data center is proposed nearby (often via a rezoning notice or Facebook group). Wants fast answers: What will this do to my property value, my electric bill, my well water, the noise at night? Needs a starting point and a path to action within minutes of landing on the site.
2. **The Emerging Organizer** — Already leading or joining a local opposition group. Needs templates, talking points, legal precedents, examples of towns that won, and a way to find and coordinate with neighbors.
3. **The Local Decision-Maker** — A city council member, planning commissioner, or county supervisor who must vote on a project and is hearing only the developer's side. Needs balanced, citable research and model ordinance language.
4. **The Journalist / Researcher** — Covering the data center boom and looking for the national picture: where projects are, where fights are happening, what the patterns are.

**Geography:** United States, national. Hotspot regions to emphasize in content: Northern Virginia, Georgia/Atlanta metro, Texas, Arizona, Ohio, Tennessee/Memphis, Pennsylvania, Indiana, Wisconsin, Oklahoma.

**Tone calibration for audience:** Visitors arrive worried and often angry. The site should channel that energy into informed action — never amplify panic, never condescend. Validate concern, then immediately give next steps.

---

## 3. Brand Voice & Design Direction

**Voice:** Plainspoken, credible, resolute. Short sentences. No jargon without explanation. Confident but never conspiratorial — every claim cited, every myth debunked with sources. We win on accuracy; industry can dismiss anger, but it can't dismiss documented facts.

**Words we use:** neighbors, community, transparency, accountability, watchdog, evidence, your right to know.
**Words we avoid:** NIMBY (reclaim/reframe it if raised), anti-technology, ban, conspiracy framing, anything that reads as anti-AI ideology rather than pro-community process.

**Visual direction:** Grassroots-meets-institutional. Clean, modern, trustworthy — closer to a public-interest research organization than a protest site. Strong data visualization aesthetic (maps, counters, charts). Yard-sign-ready color palette: high-contrast, legible at distance. *(Logo to be supplied separately — agents should derive palette and typography from it once provided.)*

**Tagline candidates (pick or refine):**
- "Know what's coming. Have a say."
- "Big Tech has lobbyists. You have neighbors."
- "Before they break ground, get the facts."

---

## 4. Site Architecture

**Top-level navigation:**

1. **Home** — Headline value proposition; live counters (projects tracked, active fights, petitions signed); "Is there a data center proposed near you?" search bar as the hero interaction; latest news; email capture.
2. **Learn** — The fact base.
   - Data Centers 101: what they are, why the boom, who builds them
   - The Real Impacts: power grid & electricity rates, water consumption, noise, air quality (diesel backup generators), property values, land use, traffic/construction
   - Myth vs. Fact: jobs claims, tax revenue claims, "it's just a warehouse" framing, NDA practices, "green" claims
   - The Incentives Problem: how tax abatements and secrecy agreements work
   - Glossary: substation, megawatt, evaporative cooling, by-right zoning, PILOT agreement, etc.
3. **Research** — The interactive tools (see Section 5).
   - National Data Center Tracker (map + database)
   - Impact Estimator
   - Legislation & Ordinance Tracker
   - Wins & Losses case study library
4. **Organize** — Find or start a local group; town hall toolkit; speaking-at-a-hearing guide; media outreach kit; how to read a rezoning application.
5. **Act** — Petitions; write-your-officials tool; donate; volunteer.
6. **Store** — Yard signs, door hangers, shirts, pins, postcards (see Section 7).
7. **News / Blog** — Weekly roundup, original analysis, guest posts from local organizers.
8. **About** — Mission, principles, funding transparency, press kit, contact.

---

## 5. Core Features & Tools (build priority order)

**Phase 1 — Launch (credibility + capture):**
- Full Learn section content (the fact base is the moat)
- National tracker v1: a structured, filterable directory of (a) data centers under construction and (b) projects under consideration — each entry with location, developer, size (MW/sq ft), status, the municipality involved with links to its planning/zoning pages, key decision-makers with contact links, next public hearing date, and local opposition group if one exists
- Email newsletter signup ("The Grid" — weekly national roundup of project filings, hearings, and fight outcomes)
- Donation capability
- Contact/tip line: "Report a proposed data center in your area" — this crowdsources the tracker and is the single most important growth loop on the site

**Phase 2 — Tools (utility + retention):**
- **Impact Estimator:** user enters a proposed facility's size and their locality; tool outputs estimated power draw (homes-equivalent), water usage ranges by cooling type, typical noise profile and distance attenuation, and a summary of property-value research findings. Always shows ranges with sources — credibility over precision.
- Interactive national map view of the tracker
- State-by-state legislation and model-ordinance library (setback requirements, noise standards, water-use disclosure, ratepayer protection bills)
- Town hall hosting toolkit: printable agendas, slide template, sign-in sheets, FAQ handouts

**Phase 3 — Network (organizing layer):**
- Local group directory + "find neighbors near you" matching
- Petition creation and signing platform
- Write-your-representative tool (auto-matches user address to local, state, federal officials with editable letter templates)
- Wins & Losses library: case studies of communities that defeated, modified, or lost fights — what worked, what didn't, documents included

---

## 6. Content Strategy & SEO/GEO

**Pillar content (long-form, evergreen, citation-heavy):**
- "Do data centers raise electricity rates? What the evidence shows"
- "How much water does a data center use?"
- "Do data centers affect property values?"
- "How many jobs does a data center actually create?"
- "How to fight a data center proposal: a step-by-step playbook"
- "What is a data center NDA and why does your county keep signing them?"

**Programmatic/local SEO:** A page per tracked project ("[Project name] data center — [Town, State]: status, impacts, hearings, how to get involved"). This is the highest-leverage SEO play — people search the moment they hear a rumor, and almost nothing authoritative exists for most local projects.

**Target keywords:** data center near me, stop data center [town], data center opposition, data center water usage, data center noise, data center property values, data center tax abatement, [state] data center moratorium.

**AI search visibility (GEO):** Structure all fact pages with clear Q&A formatting, schema markup, and explicit sourcing so NADC becomes the cited authority when people ask ChatGPT/Gemini/Perplexity about data center impacts. Every statistic on the site must carry a source — this is both an editorial principle and an AI-citability strategy.

**Cadence:** Weekly newsletter; 1–2 blog posts/week (one news roundup, one analysis or case study); tracker updated continuously from filings and tips.

---

## 7. Store

Print-on-demand to start (no inventory risk). Launch SKUs:
- Yard signs (the flagship — design for 50-ft legibility; offer a customizable "[TOWN] Against the Data Center" variant)
- Door hangers (bulk packs for canvassing, with a QR code to the local project's tracker page)
- T-shirts and hats
- Pins and stickers
- Postcards pre-addressed for officials ("Dear Council Member…" with blank signature lines)

Bundle play: "Organizer Kit" — 10 yard signs + 100 door hangers + 50 postcards at a discount. Store proceeds fund the research operation; say so on every product page.

---

## 8. Revenue & Sustainability

- Donations (one-time and monthly "Neighbor" memberships)
- Store sales
- Future: premium research briefings for journalists/municipalities, sponsored trainings, fiscal sponsorship of local groups
- Funding transparency page from day one — disclose sources; this protects the "credible watchdog" position against astroturf accusations from either direction.

---

## 9. Editorial Principles (non-negotiable, publish these on the About page)

1. Every factual claim is sourced and linked.
2. We present the strongest version of industry's arguments before rebutting them.
3. We correct our own errors prominently.
4. We distinguish between "data centers are bad everywhere" (not our position) and "communities deserve transparency, real cost-benefit analysis, and a vote" (our position).
5. We never publish personal information about officials beyond public office contact channels.

---

## 10. Calls to Action (site-wide hierarchy)

1. **Primary:** "Search your area" → tracker → project page → local actions
2. **Secondary:** Newsletter signup
3. **Tertiary:** Donate / Shop
4. **Persistent:** "Report a proposed data center" tip form

---

## 11. Launch Checklist for Agents

- [ ] Generate Business DNA from this brief
- [ ] Secure domain (preference order: neighborsagainstdatacenters.org / .com; short alias: nadc.org-style if available)
- [ ] Apply supplied logo; derive palette/typography
- [ ] Build site per Section 4 architecture, Phase 1 features
- [ ] Draft all Learn-section pillar pages per Section 6
- [ ] Configure newsletter, donation, and tip-line forms
- [ ] Implement schema markup and GEO-optimized Q&A formatting on all fact pages
- [ ] Set up store with launch SKUs
- [ ] Stand up programmatic project-page template for the tracker
