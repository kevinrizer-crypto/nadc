# Neighbors Against Data Centers — Launch, Marketing & Fundraising Strategy

*A phased plan to go from zero to a self-funding national organization: organic first, low-cost second, paid only once the model is proven.*

---

## The core logic: don't pay to learn what's free to learn

The single most expensive mistake a new advocacy org can make is buying ads before it knows its audience, message, and hooks. Paid traffic into an unproven funnel just burns cash faster. So the sequence is deliberate:

1. **Organic (Months 1–3): prove the concept for free.** Find out which message lands, which hook converts a worried homeowner into an email address, and whether the content earns links and press. Your only spend is time.
2. **Low-cost (Months 4–9): systematize what worked.** Turn the winning hooks into a content engine, build the recurring-donor base, run small paid *tests* to find your true cost-per-acquisition.
3. **Paid (Month 10+): scale a known-good machine.** Once a dollar in reliably returns more than a dollar in donor lifetime value, pour fuel on it.

The gate between each phase is **proof**, not a calendar date. The exit criteria for each phase are defined below — don't advance until you hit them.

---

## What "proof of concept" actually means here

Before any paid spend, you need three things dialed in. Track them from day one:

- **Audience:** Which segment converts best — alarmed homeowners near an active proposal, organizers already in a fight, or the broad "AI is out of control" sympathizer? They want different things and respond to different hooks.
- **Message:** Which framing pulls hardest. Test the four NADC angles against each other: *cost* (your electric bill), *resource* (your water), *secrecy* (the NDA / "they hid it from you"), and *agency* (you can actually stop this — communities blocked $156B in 2025).
- **Hook:** The specific top-of-funnel offer that captures an email. Likely candidates: "Search your area" (the tracker), "Is a data center coming near you? Get alerts," the how-to-fight playbook as a download, or a petition.

POC is reached when you can state, with data: *"For [audience], the [message] framing via the [hook] converts at X%, and an email address is worth $Y to us over 12 months."* The moment you know X and Y, paid acquisition becomes arithmetic instead of gambling.

---

## Phase 1 — Organic / Grassroots (Months 1–3)

**Goal:** Build the first 5,000–10,000 engaged emails, identify winning message/hook, and earn the first wave of press and backlinks. Minimal donation asks — you're building the asset, not harvesting it yet.

**Tactics, in priority order:**

1. **Activate the existing movement.** You are not starting from zero — there are 180+ local opposition groups across the country already fighting these projects in isolation. That is your launch audience. Reach out directly, offer NADC as the free national resource that ends their isolation (shared documents, the Wins & Losses library, the tracker). Ask each to share the playbook and link to their project's page. This is the highest-leverage move available and it costs nothing but outreach time.

2. **Publish the pillar content and the programmatic project pages.** The six pillars establish authority; the per-project pages capture the searcher at the exact moment of intent ("is a data center coming to [town]"). This is your organic acquisition engine — it works while you sleep and compounds.

3. **The tip line as a growth loop.** "Report a proposed data center near you" turns every worried visitor into both a lead and a contributor to the tracker, which creates the next project page, which captures the next searcher. Seed it manually at first from news monitoring.

4. **Earned media.** Reporters are actively covering this beat. Pitch them the thing they can't easily get: the *national picture*. Offer NADC's tracker data, the count of blocked projects, the map. Documents and data get coverage; opinions don't. Every story is a backlink that raises domain authority and a credibility signal that compounds.

5. **Organic social, issue-community native.** Don't broadcast into the void — go where the fights already are: local Facebook groups, Nextdoor, regional subreddits, and the comment sections of local-news data center stories. Show up as the helpful resource, not a brand. Repurpose pillar stats into shareable single-fact graphics ("PJM data center demand added ~$9.3B to capacity costs — here's what it did to your bill").

**Phase 1 spend:** ~$0–$500 (domain, email platform free tier, basic design tools).

**Exit criteria → advance to Phase 2 when:**
- 5,000+ emails captured
- One hook converting visitors to emails at ≥ 15–20%
- At least 2–3 earned-media placements / quality backlinks
- A clear front-runner message based on open/click/share data

---

## Phase 2 — Low-Cost / Systematize (Months 4–9)

**Goal:** Grow to ~25,000–40,000 emails, stand up the recurring-donor program (your predictability engine), and run small paid experiments to discover your real cost-per-acquisition — *without* yet scaling spend.

**Tactics:**

1. **Content cadence as a flywheel.** Lock a weekly rhythm: one news roundup ("The Grid" newsletter), one analysis or new case study, continuous tracker updates. Every new project page is a new front door from search.

2. **Launch the recurring "Neighbor" membership.** This is the most important single move in the entire plan. One-time gifts are unpredictable; monthly sustainers are forecastable revenue you can build a budget on. Make the ask modest and mission-framed ($10–$25/mo "to keep the research free for every community"). Convert your most engaged segment first.

3. **Begin disciplined monetization of the list.** Tie asks to moments of intensity — a hearing, a win, a new secrecy exposé. The narrative: small donations fund independent research that Big Tech's lobbyists can't buy. Tasteful, infrequent, credibility-protecting (see guardrails below).

4. **Small paid TESTS — emphasis on tests.** Spend small, fixed amounts ($500–$2,000 total across the phase) to learn, not to scale:
   - Boost your single best-performing organic post to measure cost-per-email.
   - Run a tiny Meta/Google campaign targeting one active-fight geography to measure cost-per-lead and cost-per-donor.
   - Test the top two message angles head-to-head with real ad dollars.
   The output you're buying is a **number**: your blended cost-per-acquisition and the 12-month value of an acquired email. You cannot responsibly scale until you have it.

5. **Store launch (print-on-demand, zero inventory risk).** Yard signs are both a revenue line and free advertising — every sign is a billboard that drives searches to NADC. Customizable "[TOWN] Against the Data Center" signs tie the national brand to the local fight. Proceeds framed as funding the research.

**Phase 2 spend:** ~$1,000–$4,000 (email/CRM platform paid tier, small ad tests, design, fundraising-processing fees).

**Exit criteria → advance to Phase 3 when:**
- 25,000+ emails
- A recurring program with 150+ sustainers and measured monthly churn
- A **known, stable cost-per-acquisition** and a **measured 12-month value per email**, where projected donor lifetime value ≥ 3× acquisition cost
- A repeatable winning ad creative + audience combination

---

## Phase 3 — Paid / Scale (Month 10+)

**Goal:** Deploy paid acquisition against proven unit economics to scale the list and recurring base aggressively, while keeping fundraising efficiency in credibility-safe territory.

**Tactics:**

1. **Scale the winning combinations only.** Pour budget into the specific audience + message + creative + hook that cleared the Phase 2 bar. Add channels one at a time (Meta → Google Search on high-intent "stop data center" terms → YouTube/short video → connected TV later), each proven before scaling.

2. **Acquisition-to-sustainer pipeline.** Optimize ads not for cheapest email but for emails that become sustainers. A $15/mo donor retained ~14 months is worth ~$210; that's the number that justifies your cost-per-acquisition, not the first gift.

3. **Geographic surge model.** When a new fight ignites in a region, surge paid spend there — intent is sky-high, local press is already covering it, and CPAs drop. NADC becomes the place that town turns to, and you capture a cohort cheaply.

4. **Always-on testing budget.** Reserve ~10–15% of ad spend for continuous experiments so the machine keeps improving and doesn't fatigue.

**Phase 3 spend:** governed by the reinvestment policy below, not a fixed number — you spend what the unit economics justify.

---

## The funnel and the metrics that matter

Everything above feeds one funnel. Watch these conversion rates; they are your diagnostic system:

`Reach → Email capture (target 15–25% of visitors on the winning hook) → Activation (took an action: signed, contacted official) → First gift (target 4–6% of list/yr) → Sustainer (target 1.5–2% of list) → Retention (track monthly churn; <5%/mo is healthy)`

The two numbers that govern the whole business:
- **Cost per acquisition (CPA):** what you pay to add an engaged email/donor.
- **Lifetime value (LTV):** what that person gives over 12–18 months.
Scale only while **LTV ≥ 3× CPA**.

---

## Fundraising forecast — Year 1

Donations come from two streams: **episodic** one-time gifts (spiky, tied to events) and **recurring** sustainers (predictable, compounding). The strategy deliberately builds the recurring base because that's what makes revenue forecastable.

**Base-case assumptions (deliberately conservative):**
- List growth: 8,000 (end Q1) → 18,000 (Q2) → 30,000 (Q3) → 45,000 (Q4)
- Episodic giving: ~2% of current list gives per quarter, average gift $35
- Recurring conversion: ~1% of list becomes monthly sustainers (cumulative), average $15/mo
- Phase 1 intentionally soft on asks, so Q1 is modest by design

| Quarter | EOQ list | Episodic gifts | Sustainers (cumulative) | Recurring collected | Quarter total |
|---|---|---|---|---|---|
| Q1 | 8,000 | $5,600 | ~80 | ~$1,800 | **~$7,400** |
| Q2 | 18,000 | $12,600 | ~180 | ~$5,900 | **~$18,500** |
| Q3 | 30,000 | $21,000 | ~300 | ~$10,800 | **~$31,800** |
| Q4 | 45,000 | $31,500 | ~450 | ~$16,900 | **~$48,400** |
| **Year 1** | | **~$70,700** | **~450** | **~$35,400** | **~$106,000** |

**Three scenarios for Year 1 total donations:**

| Scenario | Key difference | Year 1 donations |
|---|---|---|
| Conservative | Slower list growth (~30K EOY), 1.5% episodic | ~$60,000 |
| **Base** | As modeled above (45K EOY) | **~$106,000** |
| Ambitious | Faster growth (70K EOY) + a viral fight + stronger recurring | ~$220,000+ |

**The predictability engine:** the headline number isn't the $106K — it's the **exit run-rate**. Ending Year 1 with ~450 sustainers at $15/mo is **~$81,000/year in recurring revenue locked in** before you raise another episodic dollar. That recurring base is what you build a budget on, and it's the compounding asset paid acquisition is designed to grow.

*(Store revenue is separate and not counted above. Print-on-demand margins are thin per unit but the signs function as paid advertising you get paid to run — treat store contribution as a bonus and a marketing channel, not a core revenue pillar.)*

---

## Year 2 — what scaling does to the model

Once Phase 3 paid acquisition runs against proven economics, the recurring base — not episodic spikes — is what compounds:

- List to ~100,000–150,000
- Sustainers at ~1.5% of list ≈ 1,800–2,250 monthly donors
- Recurring run-rate ≈ **$27,000–$34,000/month → ~$325K–$405K/year predictable**, before episodic giving on top

That is the entire point of the sequence: organic proves it, low-cost systematizes it, paid scales a recurring base that turns into a forecastable budget.

---

## Reinvestment policy — how much goes back into fundraising

This is the question that makes or breaks sustainability. The framework:

**Cost to raise a dollar (CRD) targets, by source:**
- **House-file asks (your existing list):** ≤ $0.15 to raise $1. Email/SMS to people who already opted in is the cheapest money in fundraising. This should always be the bulk of net revenue.
- **New-donor acquisition:** up to ~$1.00 to raise $1 on the *first* gift is acceptable — acquisition often breaks even or loses money up front and is repaid by lifetime value. Judge it by LTV, not the first gift.
- **Blended target:** keep total fundraising cost at or below **$0.35 per dollar raised**, so **≥ 65¢ of every dollar funds the mission.**

**Reinvestment rate over time:**
- **Growth phase (Year 1–2):** reinvest **~30% of gross donation revenue** back into fundraising and list growth (paid acquisition, CRM/email platform, processing fees, creative). On ~$106K Year 1, that's ~$32K — and note it's *back-loaded* into Phase 3, since Phases 1–2 are nearly free.
- **Maturity (Year 3+):** as the house file grows and cheap recurring revenue dominates, taper reinvestment to **15–20%**, pushing mission funding toward 80–85%.

**The governing rules, in one place:**
1. Never scale a channel where projected 18-month LTV < 3× CPA.
2. Prioritize converting one-time donors to recurring — a sustainer is worth far more than a repeat one-time giver and costs almost nothing to retain.
3. Protect the blended CRD ceiling ($0.35). For *this* organization, fundraising efficiency isn't just financial hygiene — it's brand-critical (next section).

---

## Guardrails — protect the one thing that makes NADC work

NADC's entire competitive advantage is **credibility**. That creates fundraising constraints most orgs don't have, and they're non-negotiable:

- **No manufactured-urgency spam.** Industry will be looking for any reason to paint NADC as an astroturf grift. Aggressive, deceptive, or relentless fundraising hands them the story. Ask at moments of genuine intensity, and ask honestly.
- **Publish fundraising transparency from day one.** A clear "where the money goes" page (and that 65¢+/dollar-to-mission figure) is both an ethical commitment and a fundraising asset — it's what lets a journalist or a skeptical official trust you.
- **Keep the wall between research and revenue visible.** The fact base must never read as donation-bait. The research earns the trust; the trust earns the donations. Reverse that order and you lose both.
- **Mind the legal structure.** Whether NADC is a (c)(3) or (c)(4) changes what you can say ("tax-deductible"), how you can lobby, and how you message asks. Settle this with counsel before the first scaled campaign — it affects every donation page.

---

## 90-day quick-start checklist

1. Decide legal structure (c3 vs c4) and set up payment processing accordingly.
2. Publish the six pillars + first 10–20 project pages; turn on the tip line.
3. Direct-outreach the top 30 existing local opposition groups; offer NADC as their free national hub.
4. Stand up the email platform and "The Grid" newsletter; set the weekly content cadence.
5. Pitch 5 reporters on the national tracker data.
6. Instrument everything: capture rate by hook, message performance, list growth. You're hunting for X (conversion) and Y (value per email).
7. Soft-launch the recurring "Neighbor" membership to your most engaged 10%.
8. Hold paid ads until the Phase 2 exit criteria are met — then scale only what's proven.
