# Build Prompt for Claude Fable 5 — Neighbors Against Data Centers (NADC) Website

> **How to use this prompt:** Paste everything below the divider into Claude Fable 5. Attach the supporting files referenced in §13 (the six pillar articles, the project dataset, the brief, and the strategy doc) if you have them. Where the prompt says "ask me," let the model pause and collect what it needs from you rather than guessing.

---

## ROLE & OBJECTIVE

You are building a production-ready website for **Neighbors Against Data Centers (NADC)**, a nationwide, fact-checked hub that helps residents organize opposition to harmful data center projects in their communities. This is not a mockup or a demo. The goal is a **working site** that can be deployed to production, accept real tips, capture email and SMS subscribers, send newsletters, take donations, and sell merchandise.

An earlier version exists at **https://neighborsagainstdatacenters.com/** (canonical **https://nadc.info/**). **Fetch and study that live site first**, and stay as close as possible to its existing design language, layout, navigation, and structure. Improve where it clearly helps usability, accessibility, performance, or conversion — but the visual identity and information architecture should feel continuous, not redesigned from scratch. If you cannot access the live site, ask me for screenshots or an export before proceeding.

The two domains we control are **nadc.info** and **neighborsagainstdatacenters.com**. Treat **nadc.info as canonical** and 301-redirect the .com to it (the existing site already canonicalizes this way).

---

## NON-NEGOTIABLE PRINCIPLES

These are the reasons this organization exists. Violating them destroys its credibility, which is its only real asset.

1. **Real data only — never demo or placeholder data.** Every data center project, statistic, hearing date, and contact must be real and verifiable. If you do not have a real value, leave the field empty and flag it for human research — do not invent one.
2. **Fact-check everything.** Before publishing any factual claim, verify it against a credible primary or reputable secondary source (government records, court filings, utility commission dockets, peer-reviewed research, established news outlets). If you have web access, use it to verify. If you cannot verify a claim, mark it `UNVERIFIED` and surface it to me rather than publishing it as fact.
3. **Cite sources wherever possible.** Every statistic and factual assertion should carry a visible source link or footnote. The content I'm providing already includes source lists — preserve them. This is both an editorial commitment and an SEO/AI-citability strategy.
4. **Never fabricate citations.** A wrong or invented source is worse than no source. If you cannot find the real source for a claim, remove the claim.
5. **Do not fake working functionality.** If a feature (payments, SMS, email) needs credentials you don't have, build the real integration and leave it configured for me to add keys — clearly documented — rather than simulating success with fake responses.

---

## TECH STACK

Build a real full-stack application, not a static brochure. Recommended (substitute equivalents if you have a strong reason, but tell me why):

- **Framework:** Next.js (React) with server-side rendering for SEO, or an equivalent modern full-stack framework.
- **Database:** PostgreSQL (e.g., via Supabase or Neon) for the project tracker, tips, subscribers, and orders. Provide the schema and migrations.
- **Hosting target:** Cloudflare Pages / Vercel / Netlify for the front end; managed Postgres for data. Architect so the site sits behind **Cloudflare** for DDoS protection, CDN caching, and automatic SSL — this org expects hostile traffic, so security and resilience matter. Mask the origin.
- **Admin:** A simple authenticated admin panel (or a headless CMS) so non-technical staff can add/edit tracker entries, moderate tips, write posts, and manage products without touching code.
- **Auth for admin:** Email magic-link or OAuth with 2FA. Lock down all write endpoints.

Provide a complete README with setup, environment variables, and deploy steps.

---

## INFORMATION ARCHITECTURE (mirror the existing site)

Top-level navigation, consistent with the current site and our content plan:

1. **Home** — Value proposition; a prominent **"Is a data center proposed near you?"** search/lookup as the hero interaction; live counters (projects tracked, active fights, petitions/subscribers); latest news; email/SMS capture.
2. **Learn** — The fact base. Host the six pillar articles (provided), each with its key-takeaways box, FAQ block, and full source list:
   - Do Data Centers Raise Electricity Rates?
   - How Much Water Does a Data Center Use?
   - Do Data Centers Affect Property Values?
   - How Many Jobs Does a Data Center Actually Create?
   - What Is a Data Center NDA?
   - How to Fight a Data Center Proposal (the playbook)
   - Plus a glossary and a "Myth vs. Fact" overview assembled from the pillars.
3. **Research / Tracker** — The interactive **National Data Center Tracker**: a filterable, searchable map + database of proposed, contested, and resolved projects. Each entry links to its municipality and decision-makers and shows status, capacity, developer, nearest ZIP, hearing dates, and sources. (See dataset in §13.)
4. **Organize** — Find or start a local group; town-hall toolkit; how to read a rezoning application; the playbook.
5. **Act** — Petitions; write-your-officials tool (address → matched local/state/federal reps); donate; volunteer.
6. **Store** — Yard signs, door hangers, shirts, pins, postcards, with a customizable "[TOWN] Against the Data Center" yard-sign option.
7. **News / Blog** — Weekly roundup ("The Grid") and analysis posts.
8. **About** — Mission, editorial principles, funding transparency, press kit, contact.

Preserve the existing brand voice: plainspoken, credible, resolute, non-partisan, pro-transparency rather than anti-technology. Meta/positioning from the current site to retain: *"Nationwide, fact-checked hub turning alarmed neighbors into organized opposition to harmful data centers."*

---

## CORE FEATURES — FUNCTIONAL REQUIREMENTS

### A. National Data Center Tracker
- Render an interactive **US map** with markers for each project, plus a filterable table view (filter by state, status, developer, capacity).
- Each project has a detail page (programmatic SEO): `/tracker/[state]/[project-slug]`, titled like "[Project], [Town, State]: status, impacts, hearings, how to get involved."
- Fields per entry: project name, developer, location (city/county), nearest ZIP, latitude/longitude, status (Proposed / Contested / Approved / Withdrawn / Blocked), capacity (MW / sq ft), investment, municipality link, decision-maker contacts, next hearing date, local opposition group, and **source links**.
- The tracker is backed by the database and editable via admin. "Live data" here means **a real, staff-maintained database seeded with verified entries and continuously updated via the tip pipeline and editorial review** — there is no public third-party feed to pull from, so the update mechanism is the tip line plus admin curation. Build that pipeline.
- Seed it with the verified starting dataset in §13. Re-verify each entry's status against a current source at build time; flag any you cannot confirm.

### B. Tip Intake ("Report a data center near you")
- Public form: reporter name (optional), email, location (address/city/county/ZIP), what they know, links/uploads, consent checkbox.
- Submissions write to the database in a **moderation queue** (not auto-published). Admin reviews, verifies, and promotes to a tracker entry.
- Spam protection (honeypot + Cloudflare Turnstile, not Google reCAPTCHA). Rate-limit the endpoint.
- Send the submitter a confirmation and notify admins.

### C. Email + SMS Alerts, Newsletter
- Signup with **granular opt-in**: national newsletter, and/or alerts for a specific state or tracked project ("alert me about projects near 30223").
- **Double opt-in for email**; **explicit consent + confirmation for SMS**, with clear terms and STOP/HELP handling.
- Integrate a real ESP/SMS provider via API (recommend and scaffold; see §11). Do not build a homegrown mailer.
- Store subscriber records and preferences in the database, synced to the provider.
- **Compliance:** SMS requires carrier registration (10DLC) and documented consent; email requires CAN-SPAM-compliant footers and unsubscribe. Build these in and tell me what I must register.

### D. Donations
- Integrate **Stripe** (recommend) for one-time and **recurring monthly** ("Neighbor" membership) donations. Recurring is the priority — build a clean monthly-giving flow.
- Never handle raw card data yourself — use Stripe Checkout / Elements so card data never touches our server (PCI scope stays minimal).
- Donation receipts, a thank-you flow, and a basic admin view of donors/recurring status.
- A "where your money goes" transparency element near the ask.
- **Do not enter or hardcode any payment credentials.** Ask me for the Stripe keys, or leave clearly marked env vars.

### E. Storefront
- Product catalog (yard signs, door hangers, shirts, pins, postcards) with the customizable yard-sign variant and an "Organizer Kit" bundle.
- Cart + checkout via Stripe. If using a **print-on-demand** backend (recommend Printful/Printify to avoid inventory), scaffold that integration and ask me for the account/keys.
- Order records in the database; order-confirmation emails.

### F. Write-Your-Officials & Petitions
- Address-to-representative lookup (use a real civic-data API — recommend and scaffold; ask me for a key). Pre-filled, editable letter templates drawn from the playbook.
- Petition creation/signing tied to projects; signatures stored in the database; signers offered subscription opt-in.

---

## REQUIRED THIRD-PARTY INTEGRATIONS — AND WHAT YOU NEED FROM ME

Build the real integrations, parameterized by environment variables. For each, **pause and ask me to supply the account/keys, or document exactly what I must create.** Do not invent keys or simulate responses.

- **Payments / store checkout:** Stripe (publishable + secret keys, webhook secret).
- **Email:** an ESP with API + double opt-in (e.g., a transactional + marketing provider). Ask which I want; recommend one.
- **SMS:** an SMS API provider; flag the 10DLC/brand registration I must complete and the consent records required.
- **Print-on-demand** (if used for the store): Printful/Printify API key.
- **Representative lookup:** a civic API key.
- **Maps:** the mapping/geocoding provider for the tracker (ask for a key; recommend one with a free tier).
- **Bot protection:** Cloudflare Turnstile site/secret keys.

Produce a single `.env.example` listing every variable with a comment on where to get it, and a "Go-Live Checklist" of the external accounts and registrations I must complete before each feature is truly live.

---

## SECURITY & PRIVACY (this org will make enemies)

- Sit behind **Cloudflare**; enable WAF, rate limiting, and bot protection; hide the origin IP.
- Force HTTPS everywhere; HSTS; secure headers (CSP, X-Frame-Options, etc.).
- 2FA on all admin access; least-privilege; lock and rate-limit write endpoints and the tip/petition forms.
- Never put personal data in URLs/query strings. Encrypt sensitive fields at rest where appropriate.
- Off-site automated backups of the database; document restore.
- A clear privacy policy and, given subscribers/donors, appropriate consent logging. Protect tipster identities — treat tip submitter data as sensitive.
- Do not expose any secrets in client-side code or the repo.

---

## SEO / GEO REQUIREMENTS

- SSR for all content pages; clean semantic HTML; fast Core Web Vitals.
- Per-project tracker pages are the primary organic-acquisition engine — give each unique titles/meta, schema.org markup (e.g., `FAQPage`, `Article`, `Place`), and internal links to the relevant pillar articles.
- Structure pillar pages with the existing Q&A/FAQ formatting and explicit sourcing so AI search engines cite NADC.
- Generate `sitemap.xml` and `robots.txt`. Preserve existing canonical/OG/Twitter meta patterns from the current site (canonical to nadc.info).
- Cross-link the six pillars and the tracker as a cluster for topical authority.

---

## ACCESSIBILITY & QUALITY

- WCAG 2.1 AA: keyboard navigation, alt text, color contrast, focus states, labeled forms.
- Mobile-first and responsive — most worried homeowners arrive on phones.
- Graceful loading/empty/error states (especially the map and tracker).

---

## DELIVERABLES

1. Full source code in a clean repo with README.
2. Database schema + migrations + seed script (using the verified dataset).
3. `.env.example` with every required variable documented.
4. The six pillar articles published under **Learn**, with their key-takeaways boxes, FAQs, and source lists intact and fact-checked.
5. The tracker seeded and live-data-ready, with the tip pipeline feeding it.
6. Working (credential-pending) flows for tips, email+SMS signup, donations, and store checkout.
7. A **Go-Live Checklist**: every external account, API key, and registration (Stripe, ESP, SMS/10DLC, POD, civic API, maps, Cloudflare) I must set up, in order.
8. Deploy instructions for Cloudflare-fronted hosting on nadc.info with the .com redirect.

---

## BUILD SEQUENCE

Work in this order and check in with me at each milestone:

1. **Recon:** Fetch and document the current site's design/structure; confirm the stack with me.
2. **Scaffold:** Repo, framework, database schema, admin auth, Cloudflare-ready config.
3. **Content + Tracker:** Pillars published and fact-checked; tracker built and seeded from the verified dataset; per-project SEO pages.
4. **Capture:** Tip intake + email/SMS subscription with double opt-in and moderation.
5. **Money:** Stripe donations (recurring-first) + storefront checkout.
6. **Action tools:** Petitions + write-your-officials.
7. **Hardening + SEO + a11y pass**, then the Go-Live Checklist and deploy docs.

At each milestone, tell me what you built, what you still need from me, and anything you could not verify. **When you hit anything requiring my credentials or a real-world account, stop and ask — do not fabricate.**

---

## §13 — SUPPORTING MATERIALS I'M PROVIDING

*(Attach or paste these alongside the prompt. Tell me if any are missing.)*

- **Six pillar articles** (fact-checked, with source lists): electricity rates, water usage, property values, jobs & incentives, NDAs, and the how-to-fight playbook.
- **Verified starting dataset for the tracker** — ~30 proposed/contested/resolved projects with developer, location, county, nearest ZIP, coordinates, status, capacity, and sources. Re-verify each at build time.
- **Brand/positioning brief** and the **launch/marketing/fundraising strategy** (for voice, the "Neighbor" recurring-donation framing, and the transparency commitments).
- **Logo and any brand assets** (ask me for these; derive palette/typography from the logo and the existing site).

If any provided fact lacks a source, or any source doesn't support its claim, flag it — do not publish it. Credibility is the entire point of this organization.
